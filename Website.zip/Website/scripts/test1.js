$(document).ready(function() {
	console.log("cocks")
	$('.welcomeheader').hover(function() {
		$(this).toggleClass("spanshadow");
	});
});

console.log("cocks")


