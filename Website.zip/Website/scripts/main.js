var main = function (jQuery) {
	console.log("cocks")
	$(.welcomeheader).hover(function() {
		$(this).toggleClass("spanshadow");
	});
});
$(document).ready(main);